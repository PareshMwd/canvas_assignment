
Assignment Details
	- Drag drop assignment has been created by Vanilla JavaScript, HTML, CSS.
	- I have tested assignment in Google chrome browser.
	- For reference I am providing Google Chrome version details 
		- Version 86.0.4240.75 (Official Build) (64-bit)
		
To Run Application		
	- Please open index.html file in chrome browser to run application(No hosting required).
	- I have added background color to canvas to show actual canvas area.
		
		
	
	
	
		