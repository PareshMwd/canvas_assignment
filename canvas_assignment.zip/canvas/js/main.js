const container = window;
const canvas = document.getElementById("obsCanvas");
const context2d = canvas.getContext('2d')

let zIndex = 0;
let beingDrag = null;
let imagesArr = [];
imagesArr[zIndex++] = new ObsImage("assets/image1.jpg", context2d);
imagesArr[zIndex++] = new ObsImage("assets/image2.jpg", context2d);

let obsCanvasObj = new ObsCanvas(canvas, context2d, container, imagesArr);

window.addEventListener("resize", () => {
    obsCanvasObj.updateCanvasSize();
})

obsCanvasObj.initListeners();
