class ObsPoint {
    x = 0;
    y = 0;
    constructor(x = 0, y = 0) {
        this.x = x;
        this.y = y;
    }

    set x(val) { x = val; }
    get x() { return x; }

    set y(val) { y = val; }
    get y() { return y; }

}