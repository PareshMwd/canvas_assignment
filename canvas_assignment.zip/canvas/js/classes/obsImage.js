class ObsImage {
    MAX_WIDTH = 300;
    LINE_WIDTH = 4;
    BORDER_COLOR = "Green";

    constructor(url, context2d) {
        this.context2d = context2d;

        this.isDragging = false;
        this.hitOffset = null;
        this.pos = new ObsPoint(0, 0);

        this.image = new Image();
        this.image.onload = () => {
            if (this.image.width > this.MAX_WIDTH) {
                const aspectRatio = this.image.width / this.image.height;
                const height = Math.floor(this.MAX_WIDTH * (1 / aspectRatio));

                this.image.width = this.MAX_WIDTH;
                this.image.height = height;
            }
            context2d.drawImage(this.image, this.pos.x, this.pos.y, this.image.width, this.image.height);
        };
        this.image.src = url;
    }

    drawToPosition = (point = this.pos) => {
        this.pos = point;

        context2d.drawImage(this.image, point.x, point.y, this.image.width, this.image.height);
        if (this.isDragging) {
            context2d.lineWidth = this.LINE_WIDTH;
            context2d.strokeStyle = this.BORDER_COLOR;
            context2d.strokeRect(point.x + Math.floor(this.LINE_WIDTH / 2), point.y + Math.floor(this.LINE_WIDTH / 2), this.image.width - this.LINE_WIDTH, this.image.height - this.LINE_WIDTH);
        }
    }

    isHit = (point) => {
        if (!point) return;

        if ((point.x >= this.pos.x && point.x <= this.pos.x + this.image.width) &&
            (point.y >= this.pos.y && point.y <= this.pos.y + this.image.height)) {
            // Hitoffset - get mouse position with respect to image for drag
            this.hitOffset = new ObsPoint(Math.floor(this.pos.x - point.x), Math.floor(this.pos.y - point.y));
            return this.hitOffset;
        }
        return null;
    }

    setDragging = (isDragging) => {
        this.isDragging = isDragging;
    }
}