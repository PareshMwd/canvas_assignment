class ObsCanvas {
    BACKGROUND_COLOR = "Orange";

    constructor(canvas, context2d, container, imagesArr) {
        this.canvas = canvas;
        this.context2d = context2d;
        this.container = container;
        this.imagesArr = imagesArr;
        this.beingDrag = null;

        this.canvas.style.background = this.BACKGROUND_COLOR;
        this.updateCanvasSize();
    }

    redrawImages = () => {
        this.context2d.clearRect(0, 0, canvas.width, canvas.height);
        for (let imageObj of this.imagesArr) {
            imageObj.drawToPosition();
        }
    }

    updateCanvasSize = (width = this.container.innerWidth) => {
        this.canvas.width = width;
        this.canvas.height = Math.floor(width * (9 / 16));
        this.redrawImages();
    }

    getCollisionImage = (point) => {
        let n = this.imagesArr.length;

        for (let i = n - 1; i >= 0; i--) {
            const imageObj = this.imagesArr[i];
            if (imageObj.isHit(point)) {
                return imageObj;
            }
        }
        return null;
    }

    getNewCalculatedPosition = (event) => {
        const { hitOffset = new ObsPoint(0, 0) } = this.beingDrag;
        const newPos = { x: event.x + hitOffset.x, y: event.y + hitOffset.y };
        const { image } = this.beingDrag;
        const left = 0, top = 0, right = newPos.x + image.width, bottom = newPos.y + image.height;

        if (newPos.x <= left) { newPos.x = left; };
        if (right >= this.canvas.width) { newPos.x = (this.canvas.width - image.width ) };

        if (newPos.y <= top) { newPos.y = top; };
        if (bottom >= this.canvas.height) { newPos.y = (this.canvas.height - image.height ) };

        return newPos;
    }

    dragImage = (event) => {
        if (!this.beingDrag) return;
        const newPos = this.getNewCalculatedPosition(event);

        this.context2d.clearRect(0, 0, canvas.width, canvas.height);
        for (let imageObj of this.imagesArr) {
            if (imageObj !== this.beingDrag) {
                imageObj.drawToPosition();
            }
        }
        this.beingDrag.drawToPosition(new ObsPoint(newPos.x, newPos.y));
    }

    dropImage = () => {
        if (!this.beingDrag) return;
        this.canvas.removeEventListener("mousemove", this.dragImage);
        this.beingDrag.setDragging(false);
        this.redrawImages();
        this.beingDrag.hitOffset = null;
        this.beingDrag = null;
    }

    initListeners = () => {
        this.canvas.addEventListener("mousedown", (event) => {
            const mousePos = new ObsPoint(event.x, event.y);
            this.beingDrag = this.getCollisionImage(mousePos);
            if (this.beingDrag) {
                this.beingDrag.setDragging(true);
                this.canvas.addEventListener("mousemove", this.dragImage);
                this.dragImage(event);
            }
        })

        this.canvas.addEventListener("mouseup", this.dropImage);
        this.canvas.addEventListener("mouseleave", this.dropImage);
    }
}